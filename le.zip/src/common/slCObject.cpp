#include "slCObject.h"

LE_NAMESPACE_START

IMPLEMENT_RUNTIME_CLASS(CObject);


CObject::CObject()
{

}

CObject::~CObject()
{

}


LE_NAMESPACE_END

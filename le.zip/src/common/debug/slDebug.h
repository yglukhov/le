#pragma once

#define DEBUG

#include "slAssert.h"
#include "slCLogEntry.h"


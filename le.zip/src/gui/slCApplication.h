#pragma once

#include <common/config/slPrefix.h>

LE_NAMESPACE_START

class CApplication
{
	public:
		int run(int argc = 0, const char * const argv[] = 0);
};

LE_NAMESPACE_END

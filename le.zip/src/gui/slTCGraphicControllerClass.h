#pragma once

#include <common/config/slPrefix.h>
#include <common/class/slTCClass.h>

void _le_register_graphic_controller(CString, CString, CString);


LE_NAMESPACE_START

template <class T>
class TCGraphicControllerClass : public TCClass<T>
{
	public:
		TCGraphicControllerClass(CString className, CString themeClassName,
										 CString controlClassName);
};


template <class T>
TCGraphicControllerClass<T>::TCGraphicControllerClass(CString className,
						CString themeClassName, CString controlClassName) :
	TCClass<T>(className)
{
	_le_register_graphic_controller(className, themeClassName, controlClassName);
}


LE_NAMESPACE_END
